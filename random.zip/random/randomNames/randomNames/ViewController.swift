//
//  ViewController.swift
//  randomNames
//
//  Created by Khalid on 25/01/1444 AH.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var LabelName: UILabel!
    
    let name = ["Khalid", "Fahad", "Ali", "Latefa","Mohammed","Saud"]
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    
    @IBAction func Button(_ sender: Any) {
    
        LabelName.text = name.randomElement()
    }
    
}

