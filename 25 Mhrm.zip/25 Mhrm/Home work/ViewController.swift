//
//  ViewController.swift
//  Home work
//
//  Created by Abdullah on 25/01/1444 AH.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lebol: UILabel!
    
    
    let names = ["Ameerh", "Saeed", "Ali", "kalled","Badreah","Abdullah"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func boton1(_ sender: Any) {
        lebol.text = names.randomElement()
    }
    
}

